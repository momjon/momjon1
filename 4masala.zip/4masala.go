package main

import "fmt"

func main() {
	a := 56
	r1 := a / 10
	r2 := a % 10
	fmt.Println(r1 + r2)
}
