package main

import "fmt"

func main() {

	a := 986
	r1 := a / 100
	fmt.Println(r1)
}
